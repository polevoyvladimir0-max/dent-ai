1. Разархивируй папку на новом ПК в C:\\dent_ai (или другой путь).
2. Выполни .\\scripts\\setup_new_machine.ps1 (см. ниже).
3. Запусти docker-compose, потом backend и бота.

